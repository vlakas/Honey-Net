#!/bin/bash

cd ../logs

echo " " > log25.log 2>/dev/null
echo " " > log21.log 2>/dev/null
echo " " > log80.log 2>/dev/null
echo " " > log8080.log 2>/dev/null
echo " " > log443.log 2>/dev/null
