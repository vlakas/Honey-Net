#ifndef VSF_VERSION_H
#define VSF_VERSION_H

#define VSF_VERSION "2.3.4"

#endif /* VSF_VERSION_H */

